package sample;

public enum GameResult {
    Win,Lose,Draw
}
