package sample;
public class About extends FatherController{
    public void loadMain(){
        super.loadPage("main_scene");
    }
}
