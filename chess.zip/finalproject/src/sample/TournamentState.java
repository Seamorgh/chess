package sample;

public enum TournamentState {
    Joining,Drawing,Playing,Break,Finished
}
