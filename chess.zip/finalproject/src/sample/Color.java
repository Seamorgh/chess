package sample;

public enum Color {
    Black,White
}
